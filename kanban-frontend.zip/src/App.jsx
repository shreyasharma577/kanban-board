import React, { useMemo, useState } from 'react'
import {
  Search, Plus, Bell, Settings, ChevronDown, MoreHorizontal, Filter,
  CalendarDays, UserRound, MessageSquare, Paperclip, CheckCircle2,
  LayoutDashboard, Layers3, Users, Archive, Sparkles, SlidersHorizontal,
  X, Clock3, CircleHelp, Zap, Menu
} from 'lucide-react'
import {
  DndContext, DragOverlay, PointerSensor, closestCorners, useDroppable,
  useSensor, useSensors
} from '@dnd-kit/core'
import {
  SortableContext, verticalListSortingStrategy, useSortable, arrayMove
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'

const initialTasks = {
  todo: [
    {id:'t1', title:'Research competitor onboarding flows', tag:'Research', priority:'High', due:'Today', avatar:'AS', comments:4, files:2},
    {id:'t2', title:'Create mobile navigation concepts', tag:'Design', priority:'Medium', due:'Sep 15', avatar:'MK', comments:2, files:1},
    {id:'t3', title:'Define workspace permissions', tag:'Product', priority:'Low', due:'Sep 17', avatar:'RJ', comments:6, files:0}
  ],
  progress: [
    {id:'t4', title:'Build authentication screens', tag:'Frontend', priority:'High', due:'Tomorrow', avatar:'SK', comments:8, files:3},
    {id:'t5', title:'Set up API error states', tag:'Backend', priority:'Medium', due:'Sep 16', avatar:'NP', comments:3, files:1},
    {id:'t6', title:'Polish empty states', tag:'Design', priority:'Low', due:'Sep 18', avatar:'AS', comments:1, files:0}
  ],
  review: [
    {id:'t7', title:'Kanban board interaction spec', tag:'Product', priority:'High', due:'Today', avatar:'MK', comments:9, files:4},
    {id:'t8', title:'Responsive dashboard layout', tag:'Frontend', priority:'Medium', due:'Sep 14', avatar:'RJ', comments:5, files:2}
  ],
  done: [
    {id:'t9', title:'Create project workspace', tag:'Setup', priority:'Done', due:'Completed', avatar:'SK', comments:3, files:1},
    {id:'t10', title:'Set up design system', tag:'Design', priority:'Done', due:'Completed', avatar:'NP', comments:7, files:5}
  ]
}

const columns = [
  {id:'todo', title:'To Do', color:'violet'},
  {id:'progress', title:'In Progress', color:'blue'},
  {id:'review', title:'Review', color:'amber'},
  {id:'done', title:'Done', color:'green'}
]

function Avatar({text, small=false}) {
  return <span className={`avatar ${small ? 'small' : ''}`}>{text}</span>
}

function TaskCard({task, onOpen}) {
  const {attributes, listeners, setNodeRef, transform, transition, isDragging} = useSortable({id:task.id})
  const style = {transform: CSS.Transform.toString(transform), transition}
  return (
    <article ref={setNodeRef} style={style} className={`task-card ${isDragging ? 'dragging' : ''}`} {...attributes} {...listeners} onClick={() => onOpen(task)}>
      <div className="task-top">
        <span className={`tag ${task.tag.toLowerCase()}`}>{task.tag}</span>
        <button className="icon-btn ghost" onClick={e => e.stopPropagation()}><MoreHorizontal size={17}/></button>
      </div>
      <h3>{task.title}</h3>
      <div className="task-meta">
        <span className={`priority ${task.priority.toLowerCase()}`}><span/> {task.priority}</span>
        <span><Clock3 size={14}/> {task.due}</span>
      </div>
      <div className="task-footer">
        <Avatar text={task.avatar} small/>
        <div className="task-stats">
          <span><MessageSquare size={14}/> {task.comments}</span>
          <span><Paperclip size={14}/> {task.files}</span>
        </div>
      </div>
    </article>
  )
}

function Column({column, tasks, onAdd, onOpen}) {
  const {setNodeRef, isOver} = useDroppable({id:column.id})
  return (
    <section ref={setNodeRef} className={`kanban-column ${isOver ? 'over' : ''}`}>
      <div className="column-head">
        <div className="column-title">
          <span className={`status-dot ${column.color}`}/>
          <h2>{column.title}</h2>
          <span className="count">{tasks.length}</span>
        </div>
        <button className="icon-btn ghost"><MoreHorizontal size={18}/></button>
      </div>
      <SortableContext items={tasks.map(t => t.id)} strategy={verticalListSortingStrategy}>
        <div className="cards">
          {tasks.map(task => <TaskCard key={task.id} task={task} onOpen={onOpen}/>)}
        </div>
      </SortableContext>
      <button className="add-card" onClick={() => onAdd(column.id)}><Plus size={17}/> Add task</button>
    </section>
  )
}

function Modal({task, onClose, onSave}) {
  const [title, setTitle] = useState(task?.title || '')
  const [description, setDescription] = useState(task?.description || '')
  if (!task) return null
  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <div className="modal" onMouseDown={e => e.stopPropagation()}>
        <div className="modal-head"><div><span className="eyebrow">TASK DETAILS</span><h2>Edit task</h2></div><button className="icon-btn" onClick={onClose}><X size={20}/></button></div>
        <label>Title<input value={title} onChange={e=>setTitle(e.target.value)} autoFocus/></label>
        <label>Description<textarea value={description} onChange={e=>setDescription(e.target.value)} placeholder="Add context, links, acceptance criteria..."/></label>
        <div className="modal-grid">
          <div><span className="field-label">Status</span><div className="fake-select">{task.statusLabel || 'To Do'} <ChevronDown size={16}/></div></div>
          <div><span className="field-label">Priority</span><div className="fake-select">{task.priority} <ChevronDown size={16}/></div></div>
        </div>
        <div className="modal-actions"><button className="btn secondary" onClick={onClose}>Cancel</button><button className="btn primary" onClick={()=>onSave({...task,title,description})}>Save changes</button></div>
      </div>
    </div>
  )
}

export default function App() {
  const [tasks, setTasks] = useState(initialTasks)
  const [activeId, setActiveId] = useState(null)
  const [search, setSearch] = useState('')
  const [modalTask, setModalTask] = useState(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [filter, setFilter] = useState('All tasks')
  const sensors = useSensors(useSensor(PointerSensor, {activationConstraint:{distance:6}}))

  const allTasks = useMemo(() => Object.values(tasks).flat(), [tasks])
  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim()
    const out = {}
    for (const c of columns) {
      out[c.id] = tasks[c.id].filter(t => (!q || t.title.toLowerCase().includes(q) || t.tag.toLowerCase().includes(q)) && (filter === 'All tasks' || t.priority === filter || t.tag === filter))
    }
    return out
  }, [tasks, search, filter])

  function findContainer(id) {
    if (tasks[id]) return id
    return columns.find(c => tasks[c.id].some(t => t.id === id))?.id
  }
  function handleDragStart(e) { setActiveId(e.active.id) }
  function handleDragOver(e) {
    const {active, over} = e
    if (!over) return
    const from = findContainer(active.id), to = findContainer(over.id)
    if (!from || !to || from === to) return
    setTasks(prev => {
      const activeTask = prev[from].find(t => t.id === active.id)
      if (!activeTask) return prev
      const fromList = prev[from].filter(t => t.id !== active.id)
      const toList = [...prev[to]]
      const overIndex = toList.findIndex(t => t.id === over.id)
      toList.splice(overIndex < 0 ? toList.length : overIndex, 0, activeTask)
      return {...prev, [from]:fromList, [to]:toList}
    })
  }
  function handleDragEnd(e) {
    const {active, over} = e
    setActiveId(null)
    if (!over) return
    const container = findContainer(active.id), overContainer = findContainer(over.id)
    if (container && container === overContainer) {
      setTasks(prev => {
        const list = prev[container]
        const oldIndex = list.findIndex(t=>t.id===active.id), newIndex = list.findIndex(t=>t.id===over.id)
        return oldIndex !== newIndex ? {...prev, [container]:arrayMove(list, oldIndex, newIndex)} : prev
      })
    }
  }
  function addTask(columnId) {
    const task = {id:`t${Date.now()}`, title:'New task', tag:'Product', priority:'Medium', due:'No due date', avatar:'ME', comments:0, files:0, statusLabel:columns.find(c=>c.id===columnId)?.title}
    setTasks(p=>({...p,[columnId]:[...p[columnId],task]}))
    setModalTask(task)
  }
  function saveTask(updated) {
    setTasks(prev => {
      const next = {}
      for (const c of columns) next[c.id] = prev[c.id].map(t=>t.id===updated.id ? {...t,...updated} : t)
      return next
    })
    setModalTask(null)
  }
  const activeTask = activeId ? allTasks.find(t=>t.id===activeId) : null
  const done = tasks.done.length
  const total = allTasks.length
  const completion = total ? Math.round(done / total * 100) : 0

  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? 'open':''}`}>
        <div className="brand"><div className="brand-mark"><Layers3 size={19}/></div><span>flowboard</span><button className="mobile-close" onClick={()=>setSidebarOpen(false)}><X size={18}/></button></div>
        <div className="workspace-switch"><div className="workspace-icon">A</div><div><small>Workspace</small><strong>Acme Studio</strong></div><ChevronDown size={16}/></div>
        <nav>
          <div className="nav-label">Workspace</div>
          <a className="active"><LayoutDashboard size={18}/> Overview</a>
          <a><Layers3 size={18}/> My boards <span className="nav-count">4</span></a>
          <a><Users size={18}/> Members <span className="nav-count">12</span></a>
          <a><Archive size={18}/> Archive</a>
          <div className="nav-label second">Your boards</div>
          <a><span className="mini-dot purple"/> Product launch</a>
          <a><span className="mini-dot blue"/> Mobile app</a>
          <a><span className="mini-dot orange"/> Marketing site</a>
        </nav>
        <div className="sidebar-bottom"><div className="pro-card"><Sparkles size={17}/><div><strong>Pro workspace</strong><span>Unlock advanced features</span></div><ChevronDown size={15}/></div><div className="user-row"><Avatar text="MS"/><div><strong>My account</strong><span>shreya@example.com</span></div><MoreHorizontal size={18}/></div></div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="icon-btn mobile-menu" onClick={()=>setSidebarOpen(true)}><Menu size={21}/></button>
          <div className="breadcrumbs"><span>My boards</span><span>/</span><strong>Product launch</strong></div>
          <div className="top-actions">
            <div className="search"><Search size={17}/><input placeholder="Search tasks..." value={search} onChange={e=>setSearch(e.target.value)}/><kbd>⌘ K</kbd></div>
            <button className="icon-btn"><Bell size={18}/><i/></button>
            <button className="icon-btn"><Settings size={18}/></button>
            <Avatar text="MS"/>
          </div>
        </header>

        <div className="content">
          <div className="hero">
            <div>
              <div className="eyebrow"><span className="live-dot"/> PRODUCT LAUNCH</div>
              <h1>Build something people love.</h1>
              <p>Plan, prioritize and ship your next big thing with the team.</p>
            </div>
            <div className="hero-actions"><button className="btn secondary"><ShareIcon/> Share</button><button className="btn primary" onClick={()=>addTask('todo')}><Plus size={17}/> Add task</button></div>
          </div>

          <div className="stats-row">
            <div className="stat"><span className="stat-icon purple"><CheckCircle2 size={18}/></span><div><span>Completed</span><strong>{done} <em>of {total}</em></strong></div></div>
            <div className="stat"><span className="stat-icon blue"><Zap size={18}/></span><div><span>In progress</span><strong>{tasks.progress.length}</strong></div></div>
            <div className="stat"><span className="stat-icon orange"><CalendarDays size={18}/></span><div><span>Due today</span><strong>{allTasks.filter(t=>t.due==='Today').length}</strong></div></div>
            <div className="progress-stat"><div><span>Board progress</span><strong>{completion}%</strong></div><div className="progress-bar"><i style={{width:`${completion}%`}}/></div></div>
          </div>

          <div className="toolbar">
            <div className="view-tabs"><button className="selected">Board</button><button>List</button><button>Timeline</button></div>
            <div className="filters"><button className="filter-btn"><Filter size={15}/> Filters</button><div className="filter-wrap"><SlidersHorizontal size={15}/><select value={filter} onChange={e=>setFilter(e.target.value)}><option>All tasks</option><option>High</option><option>Medium</option><option>Low</option><option>Design</option><option>Frontend</option></select></div><button className="member-stack"><Avatar text="AS" small/><Avatar text="MK" small/><Avatar text="RJ" small/><span>+3</span></button></div>
          </div>

          <DndContext sensors={sensors} collisionDetection={closestCorners} onDragStart={handleDragStart} onDragOver={handleDragOver} onDragEnd={handleDragEnd}>
            <div className="board">
              {columns.map(c=><Column key={c.id} column={c} tasks={filtered[c.id]} onAdd={addTask} onOpen={setModalTask}/>)}
            </div>
            <DragOverlay>{activeTask ? <TaskCard task={activeTask} onOpen={()=>{}}/> : null}</DragOverlay>
          </DndContext>
        </div>
      </main>
      <Modal task={modalTask} onClose={()=>setModalTask(null)} onSave={saveTask}/>
    </div>
  )
}

function ShareIcon(){ return <Users size={16}/> }